/*练习：定义一个变量保存100，输出这个变量的值？*/
public class Demo01{
	public static void main(String[] args){
		//1.定义变量
		int a;
		//2.赋值
		a = 100;
		//3.使用：输出
		System.out.println("a");
		System.out.println(a);
	}
}