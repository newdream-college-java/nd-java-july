public class B{
	public static void main(String[] args){
		//主要内容
		System.out.println("姓名\t\t性别\t婚否");
		System.out.println("球星\t\t男\t否");
		System.out.println("欧阳建华\t男\t已婚");
	}

}