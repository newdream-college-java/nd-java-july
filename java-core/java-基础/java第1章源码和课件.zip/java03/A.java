public class A{//封面         public
	public static void main(String[] args){//主要章节开始
		//主要内容
		System.out.println("java3班有一个流氓，大家注意点！！\n今天是好日子，迎来这么多优秀的学员！！");
		System.out.println("今天是好日子，迎来这么多优秀的学员！！");
		System.out.println();

	}//主要章节结束
}//封底